const express = require('express');
const https = require('https');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 443;

// Load SSL certificate and private key
const options = {
  key: fs.readFileSync(path.join(__dirname, 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, 'cert.pem')),
};

// Middleware
app.use(express.json());

// Basic route
app.get('/', (req, res) => {
  res.send('This is "Secure" ;)');
});

// POST route for testing
app.post('/', (req, res) => {
  const data = req.body;
  res.json({ message: 'POST request successful!', receivedData: data });
});

// Start the HTTPS server
https.createServer(options, app).listen(PORT, () => {
  console.log(`Secure server listening on port ${PORT}`);
});
